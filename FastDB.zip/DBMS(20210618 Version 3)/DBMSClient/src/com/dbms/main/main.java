package com.dbms.main;

import com.dbms.view.DBMSWindow;
import com.dbms.view.Login;

public class main {
    public static void main(String[] args) {
        new Login();
    }
}