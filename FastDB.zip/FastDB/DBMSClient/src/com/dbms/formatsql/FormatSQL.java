package com.dbms.formatsql;
public class FormatSQL {
    public static int getBlankNumber(String s, int index)
    {
        if (index<s.length()) {
            if (s.charAt(index)==' ') {
                return getBlankNumber(s,index+1)+1;
            } else {
                return 0;
            }
        } else {
            return 0;
        }
    }
    public static String mergeBlank(String s)
    {
        int numberBlank = 0;
        String a1;//字符串的第一部分
        String a2;//字符串的第二部分
        for (int index =0;index<s.length(); index++) {//循环整个字符串，判断是否有连续空格
            numberBlank = getBlankNumber(s,index);
            if (numberBlank>=2) {//根据连续空格的个数以及当前的位置，截取字符串
                a1=s.substring(0,index);
                a2=s.substring(index+numberBlank-1, s.length());
                s=a1 +a2;//合并字符串
            }
        }
        return s;
    }
    public static String Formatsql(String s) {
        s=s.toLowerCase();
        s=s.replace(";"," ");
        s=s.replace("("," ");
        s=s.replace(")"," ");
        s=s.replace(","," ");
        s=s.replace("="," ");
        s=s.replace("\n"," ");
        //删除多余空格，每个单词之间只保留一个空格
        String sql=mergeBlank(s);
        //System.out.println(sql);
        String[] op=sql.split(" ");
        //for(int i=0;i<op.length;i++){
        //	System.out.println(op[i]);
        //}
        String ans=null;
        //查看数据库列表
        //show databases;
        if(op[0].equals("show")&&op[1].equals("databases")) {
            ans="getDB";
        }
        //查看某一数据库中所有表格
        //use dbName; show tables;
        else if(op[0].equals("use")&&op[2].equals("show")) {
            ans="getTable\t" + op[1];
        }
        //创建数据库
        //create database dbName;
        else if(op[0].equals("create")&&op[1].equals("database")) {
            ans="createDB\t"+op[2];
        }
        //删除数据库
        //drop database dbName;
        else if(op[0].equals("drop")&&op[1].equals("database")) {
            ans="deleteDB\t"+op[2];
        }
        //在某一数据库中创建表格
        //use dbName;create table tableName (columnName1 columnType1,columnName2 columnType2,columnName3 columnType3)
        else if(op[0].equals("use")&&op[2].equals("create")) {
            ans="createTable\t" + op[1] + "\t" + op[4]+"\t";
            for(int i=5;i<op.length;i++) {
                if(op[i]!=" ") {
                    ans+=(op[i]+"\t");
                }
            }
        }
        //删除某一数据库中的某一表格
        //use dbName;drop table tableName;
        else if(op[0].equals("use")&&op[2].equals("drop")) {
            ans="deleteTable\t" + op[1] + "\t" + op[4];
        }
        //在某数据库的某一表格中插入数据
        //use dbName;insert into tableName(columnName1, columnName2) values(value1, value2);
        else if(op[0].equals("use")&&op[2].equals("insert")) {
            ans="insert\t" + op[1] + "\t" + op[4] + "\t";
            int k=0;
            for(int i=5;i<op.length;i++) {
                if(op[i].equals("values")) {
                    k=i;
                    break;
                }
            }
            for(int i=5;i<k;i++) {
                ans+=(op[i]+"\t"+op[k+i-4]+"\t");
            }
        }
        //在某数据库的某一表格中删除数据
        //use dbName;delete from tableName where columnName=value;
        else if(op[0].equals("use")&&op[2].equals("delete")) {
            ans="delete\t" + op[1] + "\t" + op[4]+ "\t" + op[6] + "\t" + op[7];
        }
        //在某数据库的某一表格中进行数据修改
        //use dbName;update tableName set toName=toValue where fromName=fromValue;
        else if(op[0].equals("use")&&op[2].equals("update")) {
            ans= "update\t" + op[1] + "\t" + op[3]
                    + "\t" + op[8] + "\t" + op[9]
                    + "\t" + op[5] + "\t" + op[6];
        }
        //对某数据库的某一表格进行全表查询
        //use dbName;select * from tableName;
        else if(op[0].equals("use")&&op[2].equals("select")&&op.length==6) {
            ans="queryAll\t" + op[1] + "\t" + op[5];
        }
        //在某数据库的某一表格中进行条件数据查询
        //use dbName;select * from tableName where columnName=columnValue;
        else if(op[0].equals("use")&&op[2].equals("select")&&op.length>8) {
            ans="query\t" + op[1] + "\t" + op[5] + "\t" + op[7] + "\t" + op[8];
        }
        return ans;
    }

}
