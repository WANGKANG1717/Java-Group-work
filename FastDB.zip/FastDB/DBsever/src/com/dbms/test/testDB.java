package com.dbms.test;

import com.dbms.db.DB;
import com.dbms.db.Table;
import com.dbms.pair.Pair;

import java.util.ArrayList;
import java.util.HashMap;

public class testDB {
    public static void main(String[] args) throws Exception {
//        System.out.println(new DBOperator().nameValid("aa"));
//        System.out.println(new DBOperator().createDB("aa1212a"));
//        System.out.println(new DBOperator().deleteDB("aa"));
//        String[] s=new DBOperator().getDBList();
//        for(String s1:s) {
//            System.out.println(s1);
//        }
//        String[] s=DB.getDBList();
//        for(String s1:s) {
//            System.out.println(s1);
//        }
//        new DBOp("aaad").createDB();
//        new DBOp("aaad").deleteDB();
//        new Table("a", "A");
//        Table t1=new Table("QQQ", "atable");
//        HashMap<String, String> data=new HashMap<>();
//        data.put("uid", "int");
//        data.put("uname", "String");
//        data.put("uclass", "String");
//        data.put("sex", "boolean");
//        t1.createTable(data);
//        Table t1=new Table("QQW", "atable");
//        System.out.println(t1.deleteTable());
//        DB d=new DB("aaad");
//        d.deleteDB();
//        String[] s=new String[] {
//                "1111", "aaaaa", "Aaaa", "Aaaaaa",
//        };
//        t1.add(s);
//        HashMap<String, String> data=new HashMap<>();
//        data.put("uid", "11111");
//        data.put("uname", "wangkang");
//        data.put("uclass", "19yixinerban");
//        data.put("sex", "true");
//        t1.add(data);
////        t1.delete(new Pair<String, String>("uid", "112"));
//        String[] s=t1.query(new Pair<>("uid", "113"));
//        if(s!=null) {
//            for(int i=0; i<s.length; i++) {
//                System.out.print(s[i]+" ");
//            }
//        }
//        DB d=new DB("user");
//        d.createDB();
//        Table t=new Table("adaaa", "wewe");
//        String[] ss=DB.getDBList();
//        for(int i=0; i<ss.length; i++) {
//            System.out.println(ss[i]);
//        }
//        Login l=new Login();
//        Table t=new Table("QQW", "atable");
//        ArrayList<String> res=t.queryAll();
//        for(int i=0; i<res.size(); i++) {
//            System.out.println(res.get(i));
//        }
    }
}
